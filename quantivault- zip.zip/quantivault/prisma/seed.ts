import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding Quantivault database...");

  // ── Company ──────────────────────────────────────────────
  const company = await prisma.company.upsert({
    where:  { slug: "quantivault-demo" },
    update: {},
    create: {
      name:            "Quantivault Demo Corp",
      slug:            "quantivault-demo",
      country:         "NG",
      defaultCurrency: "NGN",
      subscriptionPlan:"ENTERPRISE",
      isActive:        true,
    },
  });
  console.log("✓ Company:", company.name);

  const hash = await bcrypt.hash("Demo@1234", 12);

  // ── Users ─────────────────────────────────────────────────
  const owner = await prisma.user.upsert({
    where:  { companyId_email: { companyId: company.id, email: "gideon@demo.com" } },
    update: {},
    create: { companyId: company.id, name: "Gideon Ogbe",      email: "gideon@demo.com", passwordHash: hash, role: "OWNER",            emailVerified: true, jobTitle: "Founder & CEO" },
  });
  const qs = await prisma.user.upsert({
    where:  { companyId_email: { companyId: company.id, email: "chidi@demo.com" } },
    update: {},
    create: { companyId: company.id, name: "Chidi Eze",        email: "chidi@demo.com",  passwordHash: hash, role: "QUANTITY_SURVEYOR", emailVerified: true, jobTitle: "Senior QS" },
  });
  const sm = await prisma.user.upsert({
    where:  { companyId_email: { companyId: company.id, email: "emeka@demo.com" } },
    update: {},
    create: { companyId: company.id, name: "Emeka Okafor",     email: "emeka@demo.com",  passwordHash: hash, role: "SITE_MANAGER",      emailVerified: true, jobTitle: "Site Manager" },
  });
  const fin = await prisma.user.upsert({
    where:  { companyId_email: { companyId: company.id, email: "ngozi@demo.com" } },
    update: {},
    create: { companyId: company.id, name: "Ngozi Adaeze",     email: "ngozi@demo.com",  passwordHash: hash, role: "FINANCE",           emailVerified: true, jobTitle: "Finance Manager" },
  });
  console.log("✓ Users: Gideon, Chidi, Emeka, Ngozi");

  // ── Project 1 ─────────────────────────────────────────────
  const p1 = await prisma.project.upsert({
    where:  { companyId_code: { companyId: company.id, code: "QV-2024-001" } },
    update: {},
    create: {
      companyId: company.id, name: "Lekki Commercial Complex", code: "QV-2024-001",
      clientName: "Lekki Dev Corp", projectType: "COMMERCIAL", status: "ON_TRACK",
      location: "Lagos, Nigeria", contractValue: 850000000, currency: "NGN",
      contingencyPct: 5, startDate: new Date("2024-01-15"), plannedEndDate: new Date("2024-12-31"),
      progressPct: 72,
      members: { create: [
        { userId: owner.id, role: "OWNER" },
        { userId: qs.id,    role: "QUANTITY_SURVEYOR" },
        { userId: sm.id,    role: "SITE_MANAGER" },
        { userId: fin.id,   role: "FINANCE" },
      ]},
    },
  });

  // ── Project 2 ─────────────────────────────────────────────
  const p2 = await prisma.project.upsert({
    where:  { companyId_code: { companyId: company.id, code: "QV-2024-002" } },
    update: {},
    create: {
      companyId: company.id, name: "Abuja Residential Estate", code: "QV-2024-002",
      clientName: "FCT Housing Authority", projectType: "RESIDENTIAL", status: "AT_RISK",
      location: "Abuja, Nigeria", contractValue: 620000000, currency: "NGN",
      contingencyPct: 5, startDate: new Date("2024-03-01"), plannedEndDate: new Date("2025-02-28"),
      progressPct: 45,
      members: { create: [
        { userId: owner.id, role: "OWNER" },
        { userId: qs.id,    role: "QUANTITY_SURVEYOR" },
      ]},
    },
  });

  // ── Project 3 ─────────────────────────────────────────────
  const p3 = await prisma.project.upsert({
    where:  { companyId_code: { companyId: company.id, code: "QV-2024-003" } },
    update: {},
    create: {
      companyId: company.id, name: "Port Harcourt Office Tower", code: "QV-2024-003",
      clientName: "PH Capital Ltd", projectType: "COMMERCIAL", status: "DELAYED",
      location: "Rivers, Nigeria", contractValue: 1250000000, currency: "NGN",
      contingencyPct: 5, startDate: new Date("2024-06-01"), plannedEndDate: new Date("2026-06-30"),
      progressPct: 28,
      members: { create: [
        { userId: owner.id, role: "OWNER" },
        { userId: qs.id,    role: "QUANTITY_SURVEYOR" },
        { userId: sm.id,    role: "SITE_MANAGER" },
      ]},
    },
  });
  console.log("✓ Projects: Lekki, Abuja, PH Tower");

  // ── Budget for P1 ─────────────────────────────────────────
  const existing = await prisma.costBudget.findUnique({ where: { projectId: p1.id } });
  if (!existing) {
    await prisma.costBudget.create({
      data: {
        projectId: p1.id, totalBudget: 850000000, isApproved: true, approvedAt: new Date("2024-01-20"),
        lines: { create: [
          { category: "Materials",         allocatedAmt: 382500000, committedAmt: 298000000, incurredAmt: 231000000, order: 1 },
          { category: "Labour",            allocatedAmt: 212500000, committedAmt: 178000000, incurredAmt: 142000000, order: 2 },
          { category: "Plant & Equipment", allocatedAmt: 85000000,  committedAmt: 72000000,  incurredAmt: 58000000,  order: 3 },
          { category: "Subcontract",       allocatedAmt: 127500000, committedAmt: 98000000,  incurredAmt: 72000000,  order: 4 },
          { category: "Preliminaries",     allocatedAmt: 25500000,  committedAmt: 22000000,  incurredAmt: 19000000,  order: 5 },
          { category: "Contingency",       allocatedAmt: 17000000,  committedAmt: 4000000,   incurredAmt: 0,         order: 6 },
        ]},
      },
    });
    console.log("✓ Budget created for Lekki");
  }

  // ── Vendors ───────────────────────────────────────────────
  const v1 = await prisma.vendor.findFirst({ where: { companyId: company.id, name: "Dangote Cement Plc" } });
  if (!v1) {
    await prisma.vendor.createMany({ data: [
      { companyId: company.id, name: "Dangote Cement Plc",      category: ["Materials"],              rating: 4.8, isApproved: true,  location: "Lagos" },
      { companyId: company.id, name: "CAT Equipment Rentals",   category: ["Plant & Equipment"],      rating: 4.2, isApproved: true,  location: "Lagos" },
      { companyId: company.id, name: "West Africa M&E Ltd",     category: ["Subcontract"],            rating: 3.9, isApproved: true,  location: "Lagos" },
      { companyId: company.id, name: "Lekki Labour Agency",     category: ["Labour"],                 rating: 4.1, isApproved: true,  location: "Lagos" },
      { companyId: company.id, name: "Concrete Solutions Ltd",  category: ["Materials","Subcontract"],rating: 4.4, isApproved: true,  location: "Enugu" },
      { companyId: company.id, name: "Zenith Steel Works",      category: ["Materials"],              rating: 3.6, isApproved: false, location: "Kano"  },
    ]});
    console.log("✓ Vendors seeded");
  }

  // ── AI Insights ───────────────────────────────────────────
  const insightExists = await prisma.aIInsight.findFirst({ where: { companyId: company.id } });
  if (!insightExists) {
    await prisma.aIInsight.createMany({ data: [
      {
        companyId: company.id, projectId: p3.id,
        type: "OVERRUN_PREDICTION", severity: "CRITICAL",
        title: "Budget overrun predicted — Port Harcourt Office Tower",
        body: "At current CPI of 0.79, project is projected to exceed budget by ₦262M at completion. The primary driver is the substructure phase where unexpected ground conditions have increased piling costs by 38% above BOQ rates. Immediate corrective action is required.",
        data: { cpi: 0.79, projectedOverrun: 262000000, eac: 1512000000 },
      },
      {
        companyId: company.id, projectId: p2.id,
        type: "CASHFLOW_ALERT", severity: "WARNING",
        title: "Payment overdue — Abuja Residential Estate IPA #3",
        body: "IPA #3 for ₦42M is 18 days past the contractual due date. Late payment interest is accruing under the contract terms. Issue a formal payment reminder to the FCT Housing Authority immediately.",
        data: { daysOverdue: 18, amount: 42090000 },
      },
      {
        companyId: company.id,
        type: "PERFORMANCE_SUMMARY", severity: "INFO",
        title: "Weekly portfolio performance summary",
        body: "Portfolio CPI stands at 0.94 this week. Kano Industrial Park leads at CPI 1.12. Lekki Commercial Complex is performing well at CPI 1.08. 4 of 6 projects are on or ahead of schedule.",
        data: { portfolioCPI: 0.94, onTrack: 3, atRisk: 2, delayed: 1 },
      },
    ]});
    console.log("✓ AI Insights seeded");
  }

  console.log("\n✅ Database seeded successfully!\n");
  console.log("📧 Demo login credentials:");
  console.log("   Owner:         gideon@demo.com / Demo@1234");
  console.log("   QS:            chidi@demo.com  / Demo@1234");
  console.log("   Site Manager:  emeka@demo.com  / Demo@1234");
  console.log("   Finance:       ngozi@demo.com  / Demo@1234");
}

main().catch(console.error).finally(() => prisma.$disconnect());

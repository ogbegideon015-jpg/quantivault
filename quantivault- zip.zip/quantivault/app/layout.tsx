import type { Metadata } from "next";
import { SessionProvider } from "next-auth/react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Quantivault — Construction Intelligence",
  description: "Real-time cost control, BOQ management, and AI-powered insights for construction firms.",
  keywords: ["construction", "cost management", "BOQ", "quantity surveying", "Nigeria"],
  openGraph: {
    title: "Quantivault",
    description: "Construction Intelligence Platform",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <SessionProvider>{children}</SessionProvider>
      </body>
    </html>
  );
}

import { NextRequest } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { prisma } from "@/lib/prisma";
import { requireAuth, scopeToCompany, ApiError } from "@/lib/api";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth();
    const companyId = await scopeToCompany(user);
    const { messages } = await req.json();
    if (!messages?.length) throw new ApiError(400, "Messages required");

    const projects = await prisma.project.findMany({
      where: { companyId },
      include: { costBudget: { include: { lines: true } } },
    });

    const portfolioContext = projects.map(p => ({
      id: p.code, name: p.name, status: p.status,
      progress: p.progressPct, budget: p.contractValue,
      incurred: p.costBudget?.lines?.reduce((s: number, l: any) => s + Number(l.incurredAmt), 0) || 0,
    }));

    const stream = await anthropic.messages.stream({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      system: "You are Quantivault AI, a senior construction cost consultant. Portfolio: " + JSON.stringify(portfolioContext) + ". Speak with authority. Quote specific values. Use Nigerian Naira (₦). Be concise and action-oriented.",
      messages: messages.map((m: any) => ({ role: m.role, content: m.content })),
    });

    const readable = new ReadableStream({
      async start(controller) {
        for await (const chunk of stream) {
          if (chunk.type === "content_block_delta" && chunk.delta.type === "text_delta") {
            controller.enqueue(new TextEncoder().encode("data: " + JSON.stringify({ text: chunk.delta.text }) + "\n\n"));
          }
        }
        controller.enqueue(new TextEncoder().encode("data: [DONE]\n\n"));
        controller.close();
      },
    });

    return new Response(readable, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache" } });
  } catch (e: any) {
    return Response.json({ error: e.message || "AI error" }, { status: 500 });
  }
}

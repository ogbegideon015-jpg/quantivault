import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, scopeToCompany, ok, apiHandler } from "@/lib/api";

export const GET = apiHandler(async (req: NextRequest) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  const { searchParams } = new URL(req.url);
  const insights = await prisma.aIInsight.findMany({
    where: {
      companyId,
      isDismissed: false,
      ...(searchParams.get("severity") && { severity: searchParams.get("severity") as any }),
      ...(searchParams.get("unread") === "true" && { isRead: false }),
    },
    include: { project: { select: { name:true, code:true } } },
    orderBy: [{ severity: "asc" }, { createdAt: "desc" }],
  });
  return ok(insights);
});

export const PATCH = apiHandler(async (req: NextRequest) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  const { id, action } = await req.json();
  const updated = await prisma.aIInsight.update({
    where: { id },
    data: action === "dismiss" ? { isDismissed: true } : { isRead: true },
  });
  return ok(updated);
});

import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, scopeToCompany, ok, auditLog, apiHandler, ApiError } from "@/lib/api";

export const GET = apiHandler(async (req: NextRequest, { params }: any) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  const project = await prisma.project.findFirst({
    where: { id: params.id, companyId },
    include: {
      members: { include: { user: { select: { id:true,name:true,email:true,role:true } } } },
      phases: { orderBy: { order: "asc" } },
      costBudget: { include: { lines: true } },
      contracts: true,
      _count: { select: { boqs:true,siteDiaries:true,variations:true,payments:true,purchaseOrders:true } },
    },
  });
  if (!project) throw new ApiError(404, "Project not found");
  return ok(project);
});

export const PATCH = apiHandler(async (req: NextRequest, { params }: any) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  const body = await req.json();
  const updated = await prisma.project.update({ where: { id: params.id, companyId } as any, data: body });
  await auditLog({ companyId, userId: user.id, action: "PROJECT_UPDATED", entity: "Project", entityId: params.id, after: updated });
  return ok(updated);
});

export const DELETE = apiHandler(async (req: NextRequest, { params }: any) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  if (!["OWNER","ADMIN"].includes(user.role)) throw new ApiError(403, "Only owners can delete projects");
  await prisma.project.delete({ where: { id: params.id, companyId } as any });
  return ok({ deleted: true });
});

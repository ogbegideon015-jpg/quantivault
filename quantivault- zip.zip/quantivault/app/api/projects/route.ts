import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth, scopeToCompany, validate, ok, created, apiHandler } from "@/lib/api";

const createSchema = z.object({
  name: z.string().min(3), clientName: z.string().min(2),
  projectType: z.enum(["COMMERCIAL","RESIDENTIAL","INFRASTRUCTURE","INDUSTRIAL","MIXED_USE","RENOVATION"]),
  location: z.string().min(2), description: z.string().optional(),
  contractValue: z.number().positive(), currency: z.string().default("NGN"),
  contingencyPct: z.number().default(5),
  startDate: z.string(), plannedEndDate: z.string(),
});

export const GET = apiHandler(async (req: NextRequest) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  const { searchParams } = new URL(req.url);
  const projects = await prisma.project.findMany({
    where: {
      companyId,
      ...(searchParams.get("status") && { status: searchParams.get("status") as any }),
      ...(searchParams.get("search") && { name: { contains: searchParams.get("search")!, mode: "insensitive" } }),
    },
    include: {
      members: { include: { user: { select: { id:true, name:true, role:true } } } },
      costBudget: { include: { lines: true } },
      _count: { select: { siteDiaries:true, variations:true, payments:true } },
    },
    orderBy: { createdAt: "desc" },
  });
  return ok(projects);
});

export const POST = apiHandler(async (req: NextRequest) => {
  const user = await requireAuth();
  const companyId = await scopeToCompany(user);
  const body = await validate(req, createSchema);
  const count = await prisma.project.count({ where: { companyId } });
  const code  = "QV-" + new Date().getFullYear() + "-" + String(count+1).padStart(3,"0");
  const project = await prisma.project.create({
    data: {
      ...body, companyId, code,
      startDate: new Date(body.startDate),
      plannedEndDate: new Date(body.plannedEndDate),
      members: { create: { userId: user.id, role: "OWNER" } },
    },
    include: { members: true },
  });
  return created(project);
});

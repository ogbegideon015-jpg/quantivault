import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyResetToken, clearResetToken } from "@/lib/tokens";
import { hashPassword } from "@/lib/passwords";

export async function POST(req: NextRequest) {
  const { userId, token, password } = await req.json();
  if (!userId || !token || !password) return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  const { valid, expired } = await verifyResetToken(userId, token);
  if (expired) return NextResponse.json({ error: "Link expired." }, { status: 400 });
  if (!valid)  return NextResponse.json({ error: "Invalid link." }, { status: 400 });
  await prisma.user.update({ where: { id: userId }, data: { passwordHash: await hashPassword(password) } });
  await clearResetToken(userId);
  return NextResponse.json({ success: true });
}

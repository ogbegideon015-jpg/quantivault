import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateResetToken, storeResetToken } from "@/lib/tokens";
import { sendPasswordResetEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  const { email } = await req.json();
  const user = await prisma.user.findFirst({ where: { email: { equals: email, mode: "insensitive" }, isActive: true } });
  if (user) {
    const token = await generateResetToken();
    await storeResetToken(user.id, token);
    const resetUrl = process.env.NEXTAUTH_URL + "/reset-password?token=" + token + "&userId=" + user.id;
    try { await sendPasswordResetEmail({ to: user.email, name: user.name, resetUrl }); } catch {}
  }
  return NextResponse.json({ success: true, message: "If that email exists, a reset link has been sent." });
}

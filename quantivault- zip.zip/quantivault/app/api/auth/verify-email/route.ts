import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyOTP, generateOTP, storeOTP } from "@/lib/tokens";
import { sendWelcomeEmail, sendVerificationEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  const { userId, otp } = await req.json();
  const { valid, expired } = await verifyOTP(userId, otp);
  if (expired) return NextResponse.json({ error: "OTP expired." }, { status: 400 });
  if (!valid)  return NextResponse.json({ error: "Invalid OTP." }, { status: 400 });
  const user = await prisma.user.update({ where: { id: userId }, data: { emailVerified: true }, include: { company: true } });
  try { await sendWelcomeEmail({ to: user.email, name: user.name, companyName: user.company.name }); } catch {}
  return NextResponse.json({ success: true });
}

export async function PUT(req: NextRequest) {
  const { userId } = await req.json();
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || user.emailVerified) return NextResponse.json({ error: "Not found" }, { status: 400 });
  const otp = await generateOTP();
  await storeOTP(user.id, otp);
  try { await sendVerificationEmail({ to: user.email, name: user.name, otp }); } catch {}
  return NextResponse.json({ success: true });
}

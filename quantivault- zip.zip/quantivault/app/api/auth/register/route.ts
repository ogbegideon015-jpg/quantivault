import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/passwords";
import { generateOTP, storeOTP } from "@/lib/tokens";
import { sendVerificationEmail } from "@/lib/email";

const schema = z.object({
  name: z.string().min(2), email: z.string().email(), password: z.string().min(8),
  companyName: z.string().min(2), country: z.string().default("NG"), currency: z.string().default("NGN"),
});

export async function POST(req: NextRequest) {
  try {
    const body = schema.parse(await req.json());
    const existing = await prisma.user.findFirst({ where: { email: { equals: body.email, mode: "insensitive" } } });
    if (existing) return NextResponse.json({ error: "Email already registered." }, { status: 409 });
    const slug = body.companyName.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"");
    const slugExists = await prisma.company.findUnique({ where: { slug } });
    const finalSlug = slugExists ? slug+"-"+Date.now() : slug;
    const passwordHash = await hashPassword(body.password);
    const { user, company } = await prisma.$transaction(async (tx) => {
      const company = await tx.company.create({ data: { name: body.companyName, slug: finalSlug, country: body.country, defaultCurrency: body.currency, subscriptionPlan: "FREE", trialEndsAt: new Date(Date.now()+14*86400000) } });
      const user = await tx.user.create({ data: { companyId: company.id, name: body.name, email: body.email.toLowerCase(), passwordHash, role: "OWNER", emailVerified: false } });
      return { user, company };
    });
    const otp = await generateOTP();
    await storeOTP(user.id, otp);
    try { await sendVerificationEmail({ to: user.email, name: user.name, otp }); } catch(e) {}
    return NextResponse.json({ success: true, userId: user.id, company: { id: company.id, name: company.name } }, { status: 201 });
  } catch (e: any) {
    if (e.name === "ZodError") return NextResponse.json({ error: "Validation failed" }, { status: 400 });
    return NextResponse.json({ error: "Registration failed" }, { status: 500 });
  }
}

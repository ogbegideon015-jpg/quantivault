import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const company = await prisma.company.findUnique({ where: { id: session.user.companyId } });
  if (!company?.stripeCustomerId) return NextResponse.json({ error: "No billing account" }, { status: 404 });
  const portalSession = await stripe.billingPortal.sessions.create({ customer: company.stripeCustomerId, return_url: process.env.NEXTAUTH_URL + "/settings/billing" });
  return NextResponse.json({ url: portalSession.url });
}

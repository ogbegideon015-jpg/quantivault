import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { prisma } from "@/lib/prisma";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig  = req.headers.get("stripe-signature")!;
  let event: Stripe.Event;
  try { event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: 400 }); }

  const planMap: Record<string,any> = {
    [process.env.STRIPE_STARTER_MONTHLY||""]:  "STARTER",
    [process.env.STRIPE_PRO_MONTHLY||""]:       "PROFESSIONAL",
    [process.env.STRIPE_ENTERPRISE_MONTHLY||""]:"ENTERPRISE",
    [process.env.STRIPE_STARTER_ANNUAL||""]:    "STARTER",
    [process.env.STRIPE_PRO_ANNUAL||""]:        "PROFESSIONAL",
    [process.env.STRIPE_ENTERPRISE_ANNUAL||""]:"ENTERPRISE",
  };

  switch (event.type) {
    case "customer.subscription.created":
    case "customer.subscription.updated": {
      const sub = event.data.object as Stripe.Subscription;
      const priceId = sub.items.data[0]?.price?.id;
      const plan = planMap[priceId] || "FREE";
      await prisma.company.updateMany({
        where: { stripeCustomerId: sub.customer as string },
        data: { subscriptionPlan: plan, subscriptionId: sub.id, isActive: true, trialEndsAt: sub.trial_end ? new Date(sub.trial_end*1000) : null },
      });
      break;
    }
    case "customer.subscription.deleted": {
      const sub = event.data.object as Stripe.Subscription;
      await prisma.company.updateMany({ where: { stripeCustomerId: sub.customer as string }, data: { subscriptionPlan: "FREE", subscriptionId: null } });
      break;
    }
  }
  return NextResponse.json({ received: true });
}

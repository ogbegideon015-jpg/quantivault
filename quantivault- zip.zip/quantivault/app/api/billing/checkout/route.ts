import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

const PRICES: Record<string,Record<string,string>> = {
  STARTER:      { monthly: process.env.STRIPE_STARTER_MONTHLY||"",  annual: process.env.STRIPE_STARTER_ANNUAL||""  },
  PROFESSIONAL: { monthly: process.env.STRIPE_PRO_MONTHLY||"",       annual: process.env.STRIPE_PRO_ANNUAL||""       },
  ENTERPRISE:   { monthly: process.env.STRIPE_ENTERPRISE_MONTHLY||"",annual: process.env.STRIPE_ENTERPRISE_ANNUAL||"" },
};

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { planId, interval = "monthly" } = await req.json();
  const priceId = PRICES[planId]?.[interval];
  if (!priceId) return NextResponse.json({ error: "Invalid plan" }, { status: 400 });

  let company = await prisma.company.findUnique({ where: { id: session.user.companyId } });
  if (!company) return NextResponse.json({ error: "Company not found" }, { status: 404 });

  let customerId = company.stripeCustomerId;
  if (!customerId) {
    const owner = await prisma.user.findFirst({ where: { companyId: company.id, role: "OWNER" }, select: { email:true } });
    const customer = await stripe.customers.create({ name: company.name, email: owner?.email, metadata: { companyId: company.id } });
    customerId = customer.id;
    await prisma.company.update({ where: { id: company.id }, data: { stripeCustomerId: customerId } });
  }

  const checkoutSession = await stripe.checkout.sessions.create({
    customer: customerId, mode: "subscription",
    line_items: [{ price: priceId, quantity: 1 }],
    allow_promotion_codes: true,
    success_url: process.env.NEXTAUTH_URL + "/settings/billing?success=true",
    cancel_url:  process.env.NEXTAUTH_URL + "/settings/billing?cancelled=true",
    metadata: { companyId: company.id, planId, interval },
  });

  return NextResponse.json({ url: checkoutSession.url });
}

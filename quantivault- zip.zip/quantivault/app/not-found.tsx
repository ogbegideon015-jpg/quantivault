import Link from "next/link";
export default function NotFound() {
  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#F6F8FA"}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:64,marginBottom:16}}>404</div>
        <h1 style={{color:"#1F2328",fontSize:24,fontWeight:700,marginBottom:8}}>Page not found</h1>
        <p style={{color:"#656D76",fontSize:14,marginBottom:24}}>The page you are looking for does not exist.</p>
        <Link href="/dashboard" style={{background:"#1B3A2D",color:"#fff",padding:"10px 24px",borderRadius:8,fontSize:14,fontWeight:700,textDecoration:"none"}}>Go to Dashboard</Link>
      </div>
    </div>
  );
}

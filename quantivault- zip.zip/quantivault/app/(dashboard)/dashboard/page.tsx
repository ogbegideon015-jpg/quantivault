"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";

const fmt = (n: number) => n >= 1e9 ? "₦" + (n/1e9).toFixed(2) + "B" : n >= 1e6 ? "₦" + (n/1e6).toFixed(1) + "M" : "₦" + n.toLocaleString();

const STATUS_CFG: Record<string, { label: string; color: string; bg: string; bd: string }> = {
  ON_TRACK: { label: "On Track", color: "#1A7F37", bg: "#DAFBE1", bd: "#82E9A0" },
  AT_RISK:  { label: "At Risk",  color: "#9A6700", bg: "#FFF8C5", bd: "#F0C000" },
  DELAYED:  { label: "Delayed",  color: "#CF222E", bg: "#FFEBE9", bd: "#FF8182" },
  ACTIVE:   { label: "Active",   color: "#0969DA", bg: "#DDF4FF", bd: "#80CCFF" },
};

const ACTIVITY = [
  { text: "IPA #4 certified — Lekki Complex",        time: "4m",  icon: "💳" },
  { text: "Variation V-009 approved — PH Tower",      time: "22m", icon: "📝" },
  { text: "BOQ v3 submitted — Abuja Estate",          time: "1h",  icon: "📋" },
  { text: "⚠ Duplicate payment flagged — Kano Park", time: "2h",  icon: "🚨" },
  { text: "Site diary submitted — Enugu Hub",         time: "3h",  icon: "🏗️" },
];

export default function DashboardPage() {
  const { data: session } = useSession();
  const [projects, setProjects]   = useState<any[]>([]);
  const [insights, setInsights]   = useState<any[]>([]);
  const [loading, setLoading]     = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/projects").then(r => r.json()),
      fetch("/api/ai/insights").then(r => r.json()),
    ]).then(([p, i]) => {
      setProjects(p.data || []);
      setInsights(i.data || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const user = session?.user;
  const totalValue = projects.reduce((s: number, p: any) => s + Number(p.contractValue || 0), 0);
  const onTrack    = projects.filter((p: any) => p.status === "ON_TRACK").length;
  const atRisk     = projects.filter((p: any) => p.status === "AT_RISK").length;
  const delayed    = projects.filter((p: any) => p.status === "DELAYED").length;
  const criticals  = insights.filter((i: any) => i.severity === "CRITICAL" && !i.isDismissed).length;

  const KPI = [
    { label: "Total Portfolio Value", value: fmt(totalValue),        sub: `${projects.length} active projects`,  color: "#0969DA", bg: "#DDF4FF", bd: "#80CCFF" },
    { label: "On Track",              value: onTrack + " projects",  sub: "Performing well",                      color: "#1A7F37", bg: "#DAFBE1", bd: "#82E9A0" },
    { label: "At Risk / Delayed",     value: (atRisk + delayed) + " projects", sub: "Need attention",             color: "#CF222E", bg: "#FFEBE9", bd: "#FF8182" },
    { label: "AI Alerts",             value: criticals + " critical", sub: "Unread insights",                     color: "#9A6700", bg: "#FFF8C5", bd: "#F0C000" },
  ];

  return (
    <div>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 style={{ color: "#1F2328", fontSize: 22, fontWeight: 700, margin: 0 }}>
            Good morning, {user?.name?.split(" ")[0]} 👋
          </h1>
          <p style={{ color: "#656D76", fontSize: 13, marginTop: 4 }}>Here's what's happening across your projects today.</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 8, padding: "7px 14px", display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 13 }}>📅</span>
            <span style={{ color: "#656D76", fontSize: 12.5 }}>{new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</span>
          </div>
          <Link href="/projects/new" style={{ background: "#1B3A2D", color: "#fff", border: "none", padding: "8px 18px", borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: "none" }}>+ New Project</Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 20 }}>
        {KPI.map((k, i) => (
          <div key={i} style={{ background: k.bg, border: `1px solid ${k.bd}`, borderRadius: 10, padding: "16px 18px", borderLeft: `3px solid ${k.color}` }}>
            <div style={{ color: "#656D76", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: 8 }}>{k.label}</div>
            <div style={{ color: k.color, fontSize: 22, fontWeight: 800, letterSpacing: "-0.02em", lineHeight: 1.1 }}>{loading ? "—" : k.value}</div>
            <div style={{ color: "#9198A1", fontSize: 11.5, marginTop: 6 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      {/* AI Insights banner */}
      {insights.filter((i: any) => i.severity === "CRITICAL" && !i.isDismissed).length > 0 && (
        <div style={{ background: "#FFEBE9", border: "1px solid #FF8182", borderRadius: 10, padding: "14px 18px", marginBottom: 18, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <span style={{ color: "#CF222E", fontWeight: 700, fontSize: 14 }}>⚠ {criticals} critical AI alert{criticals > 1 ? "s" : ""} require your attention</span>
            <p style={{ color: "#B91C1C", fontSize: 12.5, margin: "4px 0 0" }}>
              {insights.filter((i: any) => i.severity === "CRITICAL" && !i.isDismissed)[0]?.title}
            </p>
          </div>
          <Link href="/ai" style={{ background: "#CF222E", color: "#fff", padding: "8px 16px", borderRadius: 7, fontSize: 13, fontWeight: 700, textDecoration: "none" }}>View Insights →</Link>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 16 }}>
        {/* Projects table */}
        <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, overflow: "hidden" }}>
          <div style={{ padding: "13px 18px", background: "#F6F8FA", borderBottom: "1px solid #D0D7DE", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ color: "#1F2328", fontSize: 14, fontWeight: 700 }}>Projects</span>
            <Link href="/projects" style={{ color: "#0969DA", fontSize: 12.5, textDecoration: "none", fontWeight: 600 }}>View all →</Link>
          </div>
          {loading ? (
            <div style={{ padding: 40, textAlign: "center", color: "#9198A1" }}>Loading projects...</div>
          ) : projects.length === 0 ? (
            <div style={{ padding: 40, textAlign: "center" }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>📁</div>
              <div style={{ color: "#1F2328", fontSize: 15, fontWeight: 700, marginBottom: 6 }}>No projects yet</div>
              <div style={{ color: "#9198A1", fontSize: 13, marginBottom: 16 }}>Create your first construction project to get started.</div>
              <Link href="/projects/new" style={{ background: "#1B3A2D", color: "#fff", padding: "9px 20px", borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: "none" }}>Create Project →</Link>
            </div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#F6F8FA" }}>
                  {["Project", "Status", "Progress", "Value", "CPI"].map(h => (
                    <th key={h} style={{ padding: "8px 14px", color: "#656D76", fontSize: 10.5, fontWeight: 700, textAlign: "left", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: "1px solid #D0D7DE" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {projects.slice(0, 6).map((p: any, i: number) => {
                  const s = STATUS_CFG[p.status] || STATUS_CFG.ACTIVE;
                  const budget = p.costBudget;
                  const incurred = budget?.lines?.reduce((sum: number, l: any) => sum + Number(l.incurredAmt || 0), 0) || 0;
                  const ev = Number(p.contractValue) * Number(p.progressPct) / 100;
                  const cpi = incurred > 0 ? (ev / incurred).toFixed(2) : "N/A";
                  const cpiColor = cpi === "N/A" ? "#9198A1" : parseFloat(cpi) >= 1 ? "#1A7F37" : parseFloat(cpi) >= 0.9 ? "#9A6700" : "#CF222E";
                  return (
                    <tr key={p.id} style={{ borderBottom: "1px solid #F0F4F8", cursor: "pointer" }}
                      onMouseEnter={e => (e.currentTarget.style.background = "#F6F8FA")}
                      onMouseLeave={e => (e.currentTarget.style.background = "transparent")}>
                      <td style={{ padding: "11px 14px" }}>
                        <Link href={`/projects/${p.id}`} style={{ textDecoration: "none" }}>
                          <div style={{ color: "#1F2328", fontSize: 13, fontWeight: 600 }}>{p.name}</div>
                          <div style={{ color: "#9198A1", fontSize: 11.5, marginTop: 1 }}>{p.code} · {p.location}</div>
                        </Link>
                      </td>
                      <td style={{ padding: "11px 14px" }}>
                        <span style={{ background: s.bg, border: `1px solid ${s.bd}`, color: s.color, fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 20 }}>{s.label}</span>
                      </td>
                      <td style={{ padding: "11px 14px", minWidth: 120 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <div style={{ flex: 1, background: "#E4E9F0", borderRadius: 3, height: 5, overflow: "hidden" }}>
                            <div style={{ width: `${p.progressPct || 0}%`, height: "100%", background: s.color, borderRadius: 3 }} />
                          </div>
                          <span style={{ color: "#656D76", fontSize: 11.5 }}>{p.progressPct || 0}%</span>
                        </div>
                      </td>
                      <td style={{ padding: "11px 14px", color: "#1F2328", fontSize: 12.5, fontFamily: "monospace", fontWeight: 600 }}>{fmt(Number(p.contractValue))}</td>
                      <td style={{ padding: "11px 14px" }}>
                        <span style={{ background: "#F0F4F8", color: cpiColor, fontFamily: "monospace", fontSize: 13, fontWeight: 700, padding: "2px 8px", borderRadius: 6 }}>{cpi}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Right column */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Project health */}
          <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ color: "#1F2328", fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Project Health</div>
            {[
              { label: "On Track", count: onTrack,  color: "#1A7F37", bg: "#DAFBE1" },
              { label: "At Risk",  count: atRisk,   color: "#9A6700", bg: "#FFF8C5" },
              { label: "Delayed",  count: delayed,  color: "#CF222E", bg: "#FFEBE9" },
            ].map(s => (
              <div key={s.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #F0F4F8" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: s.color }} />
                  <span style={{ color: "#656D76", fontSize: 13 }}>{s.label}</span>
                </div>
                <span style={{ background: s.bg, color: s.color, fontSize: 13, fontWeight: 700, padding: "2px 10px", borderRadius: 20 }}>{loading ? "—" : s.count}</span>
              </div>
            ))}
          </div>

          {/* Activity */}
          <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, overflow: "hidden" }}>
            <div style={{ padding: "12px 16px", background: "#F6F8FA", borderBottom: "1px solid #D0D7DE", color: "#1F2328", fontSize: 14, fontWeight: 700 }}>Activity</div>
            <div style={{ padding: "10px 14px" }}>
              {ACTIVITY.map((a, i) => (
                <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "7px 0", borderBottom: i < 4 ? "1px solid #F0F4F8" : "none" }}>
                  <span style={{ fontSize: 14 }}>{a.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: "#1F2328", fontSize: 12, lineHeight: 1.5 }}>{a.text}</div>
                    <div style={{ color: "#9198A1", fontSize: 11, marginTop: 2 }}>{a.time} ago</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, padding: "14px 16px" }}>
            <div style={{ color: "#1F2328", fontSize: 14, fontWeight: 700, marginBottom: 10 }}>Quick Actions</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7 }}>
              {[
                ["/projects/new", "🏗️ New Project",   "#DAFBE1", "#1A7F37"],
                ["/boq",         "📋 Create BOQ",    "#DDF4FF", "#0969DA"],
                ["/payments/new","💳 New Payment",   "#FFF8C5", "#9A6700"],
                ["/reports",     "📊 Reports",       "#F6F8FA", "#656D76"],
              ].map(([href, label, bg, color]) => (
                <Link key={href as string} href={href as string} style={{ background: bg as string, border: `1px solid ${(color as string)}40`, color: color as string, padding: "9px 10px", borderRadius: 7, fontSize: 12, fontWeight: 600, textAlign: "center", textDecoration: "none", display: "block" }}>
                  {label as string}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

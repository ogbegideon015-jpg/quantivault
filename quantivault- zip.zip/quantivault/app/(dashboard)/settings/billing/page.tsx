"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

const PLANS = [
  { id:"FREE",         name:"Free",         price:0,   features:["3 projects","5 users","Basic BOQ","PDF export"] },
  { id:"STARTER",      name:"Starter",      price:49,  features:["10 projects","15 users","Full EVM","AI alerts","Excel export","Email support"] },
  { id:"PROFESSIONAL", name:"Professional", price:149, features:["50 projects","50 users","AI Assistant","Custom reports","Priority support"] },
  { id:"ENTERPRISE",   name:"Enterprise",   price:399, features:["Unlimited projects","Unlimited users","SSO","Dedicated manager","SLA guarantee"] },
];

export default function BillingPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState<string|null>(null);
  const [interval, setInterval] = useState<"monthly"|"annual">("monthly");
  const currentPlan = session?.user?.company?.plan || "FREE";

  const handleUpgrade = async (planId: string) => {
    setLoading(planId);
    const res  = await fetch("/api/billing/checkout", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ planId, interval }) });
    const data = await res.json();
    if (data.url) router.push(data.url);
    setLoading(null);
  };

  const handlePortal = async () => {
    setLoading("portal");
    const res  = await fetch("/api/billing/portal", { method:"POST" });
    const data = await res.json();
    if (data.url) router.push(data.url);
    setLoading(null);
  };

  return (
    <div>
      <h1 style={{color:"#1F2328",fontSize:21,fontWeight:700,margin:"0 0 4px"}}>Billing & Plans</h1>
      <p style={{color:"#656D76",fontSize:13,margin:"0 0 24px"}}>Current plan: <strong>{currentPlan}</strong> · Manage your subscription</p>

      {currentPlan !== "FREE" && (
        <div style={{background:"#DAFBE1",border:"1px solid #82E9A0",borderRadius:10,padding:"14px 18px",marginBottom:20,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{color:"#1A7F37",fontWeight:700,fontSize:14}}>Active Subscription</div>
            <div style={{color:"#2EA043",fontSize:13,marginTop:2}}>You are on the {currentPlan} plan. Manage invoices, payment methods, and plan changes below.</div>
          </div>
          <button onClick={handlePortal} disabled={loading==="portal"} style={{background:"#1A7F37",color:"#fff",border:"none",padding:"8px 18px",borderRadius:7,fontSize:13,fontWeight:700,cursor:"pointer"}}>{loading==="portal"?"Loading...":"Manage Billing →"}</button>
        </div>
      )}

      <div style={{display:"flex",justifyContent:"center",marginBottom:24}}>
        <div style={{display:"flex",background:"#F6F8FA",border:"1px solid #D0D7DE",borderRadius:8,padding:3}}>
          {(["monthly","annual"] as const).map(i=>(
            <button key={i} onClick={()=>setInterval(i)} style={{padding:"7px 20px",borderRadius:6,border:"none",cursor:"pointer",fontSize:13,fontWeight:600,background:interval===i?"#1B3A2D":"transparent",color:interval===i?"#fff":"#656D76"}}>
              {i==="annual"?"Annual (save 20%)":"Monthly"}
            </button>
          ))}
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14}}>
        {PLANS.map(plan=>{
          const isCurrent = plan.id === currentPlan;
          const price = interval==="annual" && plan.price > 0 ? Math.round(plan.price*0.8) : plan.price;
          return (
            <div key={plan.id} style={{background:"#fff",border:`2px solid ${isCurrent?"#1A7F37":"#D0D7DE"}`,borderRadius:12,padding:"20px 18px",position:"relative"}}>
              {isCurrent && <div style={{position:"absolute",top:-12,left:"50%",transform:"translateX(-50%)",background:"#1A7F37",color:"#fff",fontSize:10,fontWeight:700,padding:"3px 12px",borderRadius:20}}>Current Plan</div>}
              <div style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:6}}>{plan.name}</div>
              <div style={{color:"#1F2328",fontSize:28,fontWeight:900,marginBottom:16}}>{price===0?"Free":"$"+price}<span style={{fontSize:14,fontWeight:400,color:"#9198A1"}}>{price>0?"/mo":""}</span></div>
              <ul style={{listStyle:"none",padding:0,margin:"0 0 18px",display:"flex",flexDirection:"column",gap:7}}>
                {plan.features.map(f=>(<li key={f} style={{display:"flex",gap:8,color:"#656D76",fontSize:12.5}}><span style={{color:"#1A7F37"}}>✓</span>{f}</li>))}
              </ul>
              <button onClick={()=>isCurrent?handlePortal():plan.id!=="FREE"&&handleUpgrade(plan.id)} disabled={loading===plan.id||plan.id==="FREE"&&!isCurrent} style={{width:"100%",padding:10,borderRadius:8,border:`2px solid ${isCurrent?"#1A7F37":"#D0D7DE"}`,background:isCurrent?"#1A7F37":"transparent",color:isCurrent?"#fff":"#656D76",fontSize:13,fontWeight:700,cursor:plan.id==="FREE"&&!isCurrent?"default":"pointer"}}>
                {loading===plan.id?"Loading...":isCurrent?"Manage Plan":plan.id==="FREE"?"Free Plan":"Upgrade"}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import Link from "next/link";
export default function IntegrationsPage() {
  return (
    <div>
      <div style={{marginBottom:20}}>
        <h1 style={{color:"#1F2328",fontSize:21,fontWeight:700,margin:0}}>🔌 Integrations</h1>
        <p style={{color:"#656D76",fontSize:13,marginTop:4}}>Coming soon · Manage API keys, webhooks, and third-party connections.</p>
      </div>
      <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:60,textAlign:"center"}}>
        <div style={{fontSize:48,marginBottom:16}}>🔌</div>
        <h2 style={{color:"#1F2328",fontSize:18,fontWeight:700,marginBottom:8}}>Integrations</h2>
        <p style={{color:"#9198A1",fontSize:13,maxWidth:400,margin:"0 auto 24px"}}>This module is fully designed and will be connected in the next development phase.</p>
        <Link href="/dashboard" style={{background:"#1B3A2D",color:"#fff",padding:"10px 22px",borderRadius:8,fontSize:13,fontWeight:700,textDecoration:"none"}}>← Back to Dashboard</Link>
      </div>
    </div>
  );
}

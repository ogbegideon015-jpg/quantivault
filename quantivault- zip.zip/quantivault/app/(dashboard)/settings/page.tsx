"use client";
import { useSession } from "next-auth/react";
import Link from "next/link";

export default function SettingsPage() {
  const { data: session } = useSession();
  const user = session?.user;
  const SECTIONS = [
    { title:"Workspace", desc:"Company name, logo, currency settings", href:"/settings/workspace", icon:"🏢" },
    { title:"Users & Roles", desc:"Invite team members, manage permissions", href:"/settings/users", icon:"👥" },
    { title:"Billing", desc:`Current plan: ${user?.company?.plan||"FREE"} · Manage subscription`, href:"/settings/billing", icon:"💳" },
    { title:"Security", desc:"Two-factor auth, session settings, audit log", href:"/settings/security", icon:"🔒" },
    { title:"Notifications", desc:"Email and in-app notification preferences", href:"/settings/notifications", icon:"🔔" },
    { title:"Integrations", desc:"API keys, webhooks, third-party connections", href:"/settings/integrations", icon:"🔌" },
  ];
  return (
    <div>
      <h1 style={{color:"#1F2328",fontSize:21,fontWeight:700,margin:"0 0 4px"}}>Settings</h1>
      <p style={{color:"#656D76",fontSize:13,margin:"0 0 24px"}}>Manage your workspace, team, and billing</p>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
        {SECTIONS.map(s=>(
          <Link key={s.href} href={s.href} style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:"18px 20px",textDecoration:"none",display:"flex",gap:14,alignItems:"flex-start",transition:"all 0.15s"}}
            onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.borderColor="#1B3A2D";}}
            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.borderColor="#D0D7DE";}}>
            <span style={{fontSize:24,flexShrink:0}}>{s.icon}</span>
            <div>
              <div style={{color:"#1F2328",fontSize:14,fontWeight:700,marginBottom:4}}>{s.title}</div>
              <div style={{color:"#656D76",fontSize:12.5,lineHeight:1.5}}>{s.desc}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

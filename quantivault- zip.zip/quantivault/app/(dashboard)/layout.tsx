"use client";
import { useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import Link from "next/link";

const NAV = [
  { section: "Overview",  items: [
    { id: "dashboard", href: "/dashboard",    icon: "⬡", label: "Dashboard"       },
    { id: "projects",  href: "/projects",     icon: "📁", label: "Projects"        },
    { id: "analytics", href: "/analytics",    icon: "📊", label: "Analytics"       },
    { id: "reports",   href: "/reports",      icon: "📝", label: "Reports"         },
  ]},
  { section: "Project Modules", items: [
    { id: "cost",      href: "/cost",         icon: "💰", label: "Cost Control"    },
    { id: "boq",       href: "/boq",          icon: "📋", label: "BOQ & Estimates" },
    { id: "site",      href: "/site",         icon: "🏗️",  label: "Site Management" },
    { id: "procurement",href: "/procurement", icon: "🛒", label: "Procurement"     },
    { id: "contracts", href: "/contracts",    icon: "📄", label: "Contracts"       },
    { id: "payments",  href: "/payments",     icon: "💳", label: "Payments"        },
    { id: "documents", href: "/documents",    icon: "🗂️",  label: "Documents"       },
  ]},
  { section: "Intelligence", items: [
    { id: "ai",        href: "/ai",           icon: "✨", label: "AI Insights"     },
  ]},
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname   = usePathname();
  const { data: session } = useSession();
  const router     = useRouter();
  const [aiOpen, setAiOpen]   = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const user    = session?.user;
  const initials = user?.name?.split(" ").map(n=>n[0]).join("").slice(0,2) || "??";

  return (
    <div style={{ display: "flex", background: "#F6F8FA", minHeight: "100vh" }}>

      {/* Sidebar */}
      <aside style={{ width: 220, background: "#0F1923", borderRight: "1px solid #1E2D3D", height: "100vh", display: "flex", flexDirection: "column", position: "fixed", left: 0, top: 0, zIndex: 40 }}>
        {/* Logo */}
        <div style={{ padding: "16px", borderBottom: "1px solid #1E2D3D", height: 52, display: "flex", alignItems: "center", boxSizing: "border-box" }}>
          <Link href="/dashboard" style={{ display: "flex", alignItems: "center", gap: 9, textDecoration: "none" }}>
            <div style={{ width: 28, height: 28, background: "linear-gradient(135deg,#2B6FE8,#1A3A8F)", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 900, fontSize: 14 }}>Q</div>
            <div>
              <div style={{ color: "#D8E4F0", fontSize: 13, fontWeight: 700 }}>Quantivault</div>
              <div style={{ color: "#4A5E78", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.1em" }}>Construction Intel</div>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, overflowY: "auto", padding: "12px 8px" }}>
          {NAV.map(section => (
            <div key={section.section} style={{ marginBottom: 8 }}>
              <div style={{ color: "#3A4D66", fontSize: 9.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.12em", padding: "6px 10px 4px" }}>{section.section}</div>
              {section.items.map(item => {
                const active = pathname === item.href || pathname.startsWith(item.href + "/");
                return (
                  <Link key={item.id} href={item.href} style={{
                    display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", borderRadius: 7,
                    marginBottom: 1, textDecoration: "none",
                    background: active ? "rgba(43,111,232,0.18)" : "transparent",
                    color: active ? "#388BFD" : "#7A8EA8",
                    fontSize: 12.5, fontWeight: active ? 600 : 400,
                    borderLeft: active ? "2px solid #388BFD" : "2px solid transparent",
                    transition: "all 0.15s",
                  }}>
                    <span style={{ fontSize: 14 }}>{item.icon}</span>{item.label}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Upgrade banner */}
        {user?.company?.plan === "FREE" && (
          <div style={{ margin: "0 8px 8px", background: "linear-gradient(135deg,#1A1200,#2A1E00)", border: "1px solid rgba(212,160,23,0.3)", borderRadius: 8, padding: "11px 12px" }}>
            <div style={{ color: "#D4A017", fontSize: 11.5, fontWeight: 700, marginBottom: 3 }}>✨ Upgrade to Pro</div>
            <div style={{ color: "#7A8EA8", fontSize: 10.5, marginBottom: 8, lineHeight: 1.5 }}>AI insights, unlimited projects & more.</div>
            <Link href="/settings/billing" style={{ display: "block", background: "#D4A017", color: "#000", padding: "6px", borderRadius: 6, fontSize: 11.5, fontWeight: 800, textAlign: "center", textDecoration: "none" }}>Upgrade Now</Link>
          </div>
        )}

        {/* User */}
        <div style={{ padding: "10px 12px", borderTop: "1px solid #1E2D3D" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: "linear-gradient(135deg,#2B6FE8,#1A3A8F)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 11, fontWeight: 800, flexShrink: 0 }}>{initials}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: "#D8E4F0", fontSize: 12, fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user?.name}</div>
              <div style={{ color: "#4A5E78", fontSize: 10 }}>{user?.role?.replace(/_/g," ")}</div>
            </div>
            <button onClick={() => signOut({ callbackUrl: "/login" })} title="Sign out"
              style={{ background: "transparent", border: "none", color: "#4A5E78", cursor: "pointer", fontSize: 14, padding: 4 }}>⎋</button>
          </div>
        </div>
      </aside>

      {/* Top bar */}
      <div style={{ position: "fixed", top: 0, left: 220, right: 0, height: 52, background: "#0F1923", borderBottom: "1px solid #1E2D3D", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px", zIndex: 30 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#1A2535", border: "1px solid #2E3D52", borderRadius: 7, padding: "6px 12px", width: 280 }}>
          <span style={{ color: "#4A5E78" }}>🔍</span>
          <span style={{ color: "#4A5E78", fontSize: 12.5 }}>Search projects, documents...</span>
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          {/* Notifications */}
          <div style={{ position: "relative" }}>
            <button onClick={() => setNotifOpen(o=>!o)} style={{ background: "transparent", border: "none", color: "#7A8EA8", fontSize: 18, cursor: "pointer", position: "relative" }}>🔔
              <div style={{ position: "absolute", top: -2, right: -2, width: 14, height: 14, background: "#CF222E", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 8, color: "#fff", fontWeight: 700 }}>3</div>
            </button>
          </div>
          {/* AI */}
          <Link href="/ai" style={{ background: "#D4A017", border: "none", color: "#000", padding: "5px 12px", borderRadius: 7, fontSize: 12, fontWeight: 700, textDecoration: "none", display: "flex", alignItems: "center", gap: 4 }}>✨ AI</Link>
          {/* Settings */}
          <Link href="/settings" style={{ color: "#7A8EA8", fontSize: 18, textDecoration: "none" }}>⚙️</Link>
          {/* Avatar */}
          <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg,#2B6FE8,#1A3A8F)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 10, fontWeight: 800 }}>{initials}</div>
        </div>
      </div>

      {/* Main content */}
      <main style={{ marginLeft: 220, marginTop: 52, flex: 1, padding: "24px 28px", overflowY: "auto", minHeight: "calc(100vh - 52px)" }}>
        {children}
      </main>
    </div>
  );
}

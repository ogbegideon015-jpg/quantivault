"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function NewProjectPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name:"",clientName:"",projectType:"COMMERCIAL",location:"",description:"",contractValue:"",currency:"NGN",contingencyPct:"5",startDate:"",plannedEndDate:"" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const update = (k:string,v:string) => setForm(f=>({...f,[k]:v}));
  const inp: React.CSSProperties = { width:"100%",border:"1.5px solid #D0D7DE",borderRadius:8,padding:"10px 12px",fontSize:14,outline:"none",fontFamily:"inherit",boxSizing:"border-box",background:"#F6F8FA" };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError("");
    const res  = await fetch("/api/projects", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({...form,contractValue:Number(form.contractValue),contingencyPct:Number(form.contingencyPct)}) });
    const data = await res.json();
    if (!res.ok) { setError(data.error||"Failed to create project"); setLoading(false); return; }
    router.push("/projects/"+data.data.id);
  };

  return (
    <div style={{maxWidth:680,margin:"0 auto"}}>
      <div style={{marginBottom:20}}>
        <Link href="/projects" style={{color:"#0969DA",textDecoration:"none",fontSize:12.5}}>← Projects</Link>
        <h1 style={{color:"#1F2328",fontSize:21,fontWeight:700,margin:"8px 0 4px"}}>New Project</h1>
        <p style={{color:"#656D76",fontSize:13,margin:0}}>Fill in the details to create your project</p>
      </div>
      {error && <div style={{background:"#FFEBE9",border:"1px solid #FF8182",borderRadius:8,padding:"10px 14px",marginBottom:16,color:"#CF222E",fontSize:13}}>{error}</div>}
      <form onSubmit={handleSubmit}>
        <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:"20px 24px",marginBottom:14}}>
          <h2 style={{color:"#1F2328",fontSize:15,fontWeight:700,margin:"0 0 16px"}}>Basic Information</h2>
          <div style={{display:"grid",gap:14}}>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Project Name *</label><input value={form.name} onChange={e=>update("name",e.target.value)} required placeholder="e.g. Lekki Commercial Complex" style={inp}/></div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Client Name *</label><input value={form.clientName} onChange={e=>update("clientName",e.target.value)} required placeholder="Client or organisation" style={inp}/></div>
              <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Project Type *</label>
                <select value={form.projectType} onChange={e=>update("projectType",e.target.value)} style={inp}>
                  {["COMMERCIAL","RESIDENTIAL","INFRASTRUCTURE","INDUSTRIAL","MIXED_USE","RENOVATION"].map(t=>(<option key={t} value={t}>{t.replace(/_/g," ")}</option>))}
                </select>
              </div>
            </div>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Location *</label><input value={form.location} onChange={e=>update("location",e.target.value)} required placeholder="e.g. Lagos, Nigeria" style={inp}/></div>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Description</label><textarea value={form.description} onChange={e=>update("description",e.target.value)} rows={3} placeholder="Brief project description..." style={{...inp,resize:"vertical"}}/></div>
          </div>
        </div>
        <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:"20px 24px",marginBottom:14}}>
          <h2 style={{color:"#1F2328",fontSize:15,fontWeight:700,margin:"0 0 16px"}}>Financial Details</h2>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Contract Value *</label><input value={form.contractValue} onChange={e=>update("contractValue",e.target.value)} required type="number" placeholder="850000000" style={inp}/></div>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Currency</label>
              <select value={form.currency} onChange={e=>update("currency",e.target.value)} style={inp}>
                {[["NGN","NGN — ₦"],["USD","USD — $"],["GBP","GBP — £"],["EUR","EUR — €"],["GHS","GHS — ₵"]].map(([v,l])=>(<option key={v} value={v}>{l}</option>))}
              </select>
            </div>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Start Date *</label><input value={form.startDate} onChange={e=>update("startDate",e.target.value)} required type="date" style={inp}/></div>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Planned End Date *</label><input value={form.plannedEndDate} onChange={e=>update("plannedEndDate",e.target.value)} required type="date" style={inp}/></div>
            <div><label style={{color:"#656D76",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.07em",display:"block",marginBottom:5}}>Contingency %</label><input value={form.contingencyPct} onChange={e=>update("contingencyPct",e.target.value)} type="number" min="0" max="30" style={inp}/></div>
          </div>
        </div>
        <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
          <Link href="/projects" style={{background:"#F6F8FA",border:"1px solid #D0D7DE",color:"#656D76",padding:"10px 20px",borderRadius:8,fontSize:13,textDecoration:"none",fontWeight:600}}>Cancel</Link>
          <button type="submit" disabled={loading} style={{background:"#1B3A2D",color:"#fff",border:"none",padding:"10px 24px",borderRadius:8,fontSize:13,fontWeight:700,cursor:loading?"not-allowed":"pointer"}}>{loading?"Creating...":"Create Project →"}</button>
        </div>
      </form>
    </div>
  );
}

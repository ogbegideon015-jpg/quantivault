"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";

const fmt = (n: number) => n >= 1e9 ? "\u20a6"+(n/1e9).toFixed(2)+"B" : n >= 1e6 ? "\u20a6"+(n/1e6).toFixed(1)+"M" : "\u20a6"+n.toLocaleString();
const STATUS: Record<string,any> = { ON_TRACK:{label:"On Track",color:"#1A7F37",bg:"#DAFBE1",bd:"#82E9A0"}, AT_RISK:{label:"At Risk",color:"#9A6700",bg:"#FFF8C5",bd:"#F0C000"}, DELAYED:{label:"Delayed",color:"#CF222E",bg:"#FFEBE9",bd:"#FF8182"}, ACTIVE:{label:"Active",color:"#0969DA",bg:"#DDF4FF",bd:"#80CCFF"} };
const TABS = ["Overview","Cost Control","BOQ","Procurement","Payments","Site","Documents"];

export default function ProjectDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const [project, setProject] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("Overview");

  useEffect(() => { fetch("/api/projects/"+id).then(r=>r.json()).then(d=>{ setProject(d.data); setLoading(false); }); }, [id]);

  if (loading) return <div style={{padding:60,textAlign:"center",color:"#9198A1"}}>Loading...</div>;
  if (!project) return <div style={{padding:60,textAlign:"center"}}>Project not found. <Link href="/projects">Back to projects</Link></div>;

  const s = STATUS[project.status] || STATUS.ACTIVE;
  const totalIncurred = project.costBudget?.lines?.reduce((sum:number,l:any)=>sum+Number(l.incurredAmt||0),0)||0;
  const ev = Number(project.contractValue) * Number(project.progressPct)/100;
  const cpi = totalIncurred > 0 ? (ev/totalIncurred).toFixed(2) : "N/A";

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:16,color:"#656D76",fontSize:12.5}}>
        <Link href="/projects" style={{color:"#0969DA",textDecoration:"none"}}>Projects</Link>
        <span>/</span><span style={{color:"#1F2328"}}>{project.name}</span>
      </div>
      <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:"18px 22px",marginBottom:16,borderLeft:`4px solid ${s.color}`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
              <h1 style={{color:"#1F2328",fontSize:19,fontWeight:700,margin:0}}>{project.name}</h1>
              <span style={{background:s.bg,border:`1px solid ${s.bd}`,color:s.color,fontSize:11,fontWeight:700,padding:"2px 8px",borderRadius:20}}>{s.label}</span>
              <span style={{background:"#F0F4F8",color:"#656D76",fontSize:11,padding:"2px 8px",borderRadius:6}}>{project.code}</span>
            </div>
            <div style={{display:"flex",gap:16,flexWrap:"wrap"}}>
              {[["\u{1f4cd}",project.location],["\u{1f4cb}",project.clientName],["\u{1f4c5}",new Date(project.startDate).toLocaleDateString()+" → "+new Date(project.plannedEndDate).toLocaleDateString()]].map(([ic,v])=>(<span key={v} style={{color:"#656D76",fontSize:12.5}}>{ic} {v}</span>))}
            </div>
          </div>
          <div style={{display:"flex",gap:8}}>
            <button onClick={()=>router.push("/projects/"+id+"/edit")} style={{background:"#F6F8FA",border:"1px solid #D0D7DE",color:"#656D76",padding:"7px 14px",borderRadius:7,cursor:"pointer",fontSize:12.5}}>Edit</button>
          </div>
        </div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:10,marginBottom:16}}>
        {[["Contract Value",fmt(Number(project.contractValue)),"#0969DA"],["Cost Incurred",fmt(totalIncurred),"#9A6700"],["Progress",project.progressPct+"%","#1A7F37"],["CPI",cpi,parseFloat(cpi)>=1?"#1A7F37":parseFloat(cpi)>=0.9?"#9A6700":"#CF222E"],["Members",project.members?.length||0,"#656D76"]].map(([l,v,c])=>(
          <div key={l} style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:8,padding:"12px 14px",borderTop:`2px solid ${c}`}}>
            <div style={{color:"#656D76",fontSize:10.5,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:5}}>{l}</div>
            <div style={{color:c,fontSize:18,fontWeight:800}}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{display:"flex",background:"#fff",border:"1px solid #D0D7DE",borderRadius:8,padding:3,marginBottom:16,width:"fit-content",gap:2}}>
        {TABS.map(t=>(<button key={t} onClick={()=>setTab(t)} style={{padding:"6px 14px",borderRadius:6,border:"none",cursor:"pointer",fontSize:12.5,fontWeight:600,background:tab===t?"#1B3A2D":"transparent",color:tab===t?"#fff":"#656D76"}}>{t}</button>))}
      </div>
      <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:40,textAlign:"center"}}>
        <div style={{fontSize:36,marginBottom:12}}>{"\u{1f6a7}"}</div>
        <div style={{color:"#1F2328",fontSize:16,fontWeight:700,marginBottom:6}}>{tab} Module</div>
        <div style={{color:"#9198A1",fontSize:13}}>This module is being built. Check back soon.</div>
      </div>
    </div>
  );
}

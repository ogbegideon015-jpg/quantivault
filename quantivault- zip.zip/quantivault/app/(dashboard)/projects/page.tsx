"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

const fmt = (n: number) => n >= 1e9 ? "₦" + (n/1e9).toFixed(2) + "B" : n >= 1e6 ? "₦" + (n/1e6).toFixed(1) + "M" : "₦" + n.toLocaleString();

const STATUS: Record<string, any> = {
  ON_TRACK: { label: "On Track", color: "#1A7F37", bg: "#DAFBE1", bd: "#82E9A0" },
  AT_RISK:  { label: "At Risk",  color: "#9A6700", bg: "#FFF8C5", bd: "#F0C000" },
  DELAYED:  { label: "Delayed",  color: "#CF222E", bg: "#FFEBE9", bd: "#FF8182" },
  ACTIVE:   { label: "Active",   color: "#0969DA", bg: "#DDF4FF", bd: "#80CCFF" },
  COMPLETED:{ label: "Done",     color: "#656D76", bg: "#F6F8FA", bd: "#D0D7DE" },
};

export default function ProjectsPage() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [filter,   setFilter]   = useState("ALL");
  const [search,   setSearch]   = useState("");
  const [view,     setView]     = useState<"table"|"grid">("table");
  const [sortBy,   setSortBy]   = useState("name");
  const [sortDir,  setSortDir]  = useState(1);

  useEffect(() => {
    fetch("/api/projects").then(r => r.json()).then(d => { setProjects(d.data || []); setLoading(false); });
  }, []);

  const toggleSort = (col: string) => { if (sortBy === col) setSortDir(d => -d); else { setSortBy(col); setSortDir(1); } };

  const filtered = projects
    .filter(p => (filter === "ALL" || p.status === filter) && (p.name + p.location + p.clientName).toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      const av = a[sortBy], bv = b[sortBy];
      return typeof av === "string" ? av.localeCompare(bv) * sortDir : (Number(av) - Number(bv)) * sortDir;
    });

  const SortTh = ({ col, label, right }: any) => (
    <th onClick={() => toggleSort(col)} style={{ padding: "9px 14px", color: sortBy === col ? "#B8860B" : "#656D76", fontSize: 10.5, fontWeight: 700, textAlign: right ? "right" : "left", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: "1px solid #D0D7DE", background: "#F6F8FA", cursor: "pointer", whiteSpace: "nowrap", userSelect: "none" }}>
      {label} {sortBy === col ? (sortDir === 1 ? "↑" : "↓") : <span style={{ opacity: 0.3 }}>↕</span>}
    </th>
  );

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <h1 style={{ color: "#1F2328", fontSize: 21, fontWeight: 700, margin: 0 }}>Projects</h1>
          <p style={{ color: "#656D76", fontSize: 13, marginTop: 3 }}>{projects.length} projects · {fmt(projects.reduce((s, p) => s + Number(p.contractValue || 0), 0))} total value</p>
        </div>
        <Link href="/projects/new" style={{ background: "#1B3A2D", color: "#fff", padding: "9px 20px", borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: "none" }}>+ New Project</Link>
      </div>

      {/* Toolbar */}
      <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, padding: "12px 14px", marginBottom: 14, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍  Search projects..."
          style={{ flex: 1, minWidth: 180, background: "#F6F8FA", border: "1px solid #D0D7DE", borderRadius: 7, padding: "8px 12px", color: "#1F2328", fontSize: 13, outline: "none" }} />
        <div style={{ display: "flex", background: "#F6F8FA", border: "1px solid #D0D7DE", borderRadius: 7, overflow: "hidden" }}>
          {[["ALL","All"],["ON_TRACK","On Track"],["AT_RISK","At Risk"],["DELAYED","Delayed"]].map(([v,l]) => (
            <button key={v} onClick={() => setFilter(v)} style={{ padding: "7px 14px", border: "none", cursor: "pointer", fontSize: 12.5, fontWeight: 600, background: filter===v ? "#1B3A2D" : "transparent", color: filter===v ? "#fff" : "#656D76", borderRight: "1px solid #D0D7DE" }}>{l}</button>
          ))}
        </div>
        <div style={{ display: "flex", background: "#F6F8FA", border: "1px solid #D0D7DE", borderRadius: 7, overflow: "hidden" }}>
          {[["☰","table"],["⊞","grid"]].map(([ic,v]) => (
            <button key={v} onClick={() => setView(v as any)} style={{ padding: "7px 12px", border: "none", cursor: "pointer", background: view===v ? "#1B3A2D" : "transparent", color: view===v ? "#fff" : "#9198A1", fontSize: 16 }}>{ic}</button>
          ))}
        </div>
        <span style={{ color: "#9198A1", fontSize: 12 }}>{filtered.length} result{filtered.length !== 1 ? "s" : ""}</span>
      </div>

      {loading && <div style={{ textAlign: "center", padding: 60, color: "#9198A1" }}>Loading projects...</div>}

      {!loading && filtered.length === 0 && (
        <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, padding: 60, textAlign: "center" }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📁</div>
          <div style={{ color: "#1F2328", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>No projects found</div>
          <div style={{ color: "#9198A1", fontSize: 13, marginBottom: 20 }}>
            {search || filter !== "ALL" ? "Try adjusting your filters." : "Create your first project to get started."}
          </div>
          {!search && filter === "ALL" && (
            <Link href="/projects/new" style={{ background: "#1B3A2D", color: "#fff", padding: "10px 22px", borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: "none" }}>Create First Project →</Link>
          )}
        </div>
      )}

      {/* Table view */}
      {!loading && filtered.length > 0 && view === "table" && (
        <div style={{ background: "#fff", border: "1px solid #D0D7DE", borderRadius: 10, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <SortTh col="name" label="Project" />
                <SortTh col="projectType" label="Type" />
                <SortTh col="status" label="Status" />
                <SortTh col="progressPct" label="Progress" />
                <SortTh col="contractValue" label="Budget" right />
                <th style={{ padding: "9px 14px", color: "#656D76", fontSize: 10.5, fontWeight: 700, textAlign: "left", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: "1px solid #D0D7DE", background: "#F6F8FA" }}>PM</th>
                <th style={{ padding: "9px 14px", background: "#F6F8FA", borderBottom: "1px solid #D0D7DE" }}></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p, i) => {
                const s = STATUS[p.status] || STATUS.ACTIVE;
                return (
                  <tr key={p.id} style={{ borderBottom: "1px solid #F0F4F8", cursor: "pointer" }}
                    onMouseEnter={e => (e.currentTarget.style.background = "#F6F8FA")}
                    onMouseLeave={e => (e.currentTarget.style.background = "transparent")}>
                    <td style={{ padding: "12px 14px" }}>
                      <div style={{ color: "#1F2328", fontSize: 13, fontWeight: 700 }}>{p.name}</div>
                      <div style={{ color: "#9198A1", fontSize: 11.5, marginTop: 1 }}>{p.code} · {p.clientName} · {p.location}</div>
                    </td>
                    <td style={{ padding: "12px 14px" }}>
                      <span style={{ background: "#F0F4F8", color: "#656D76", fontSize: 11.5, padding: "2px 8px", borderRadius: 6 }}>{p.projectType?.replace(/_/g," ")}</span>
                    </td>
                    <td style={{ padding: "12px 14px" }}>
                      <span style={{ background: s.bg, border: `1px solid ${s.bd}`, color: s.color, fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 20 }}>{s.label}</span>
                    </td>
                    <td style={{ padding: "12px 14px", minWidth: 120 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ flex: 1, background: "#E4E9F0", borderRadius: 3, height: 5, overflow: "hidden" }}>
                          <div style={{ width: `${p.progressPct || 0}%`, height: "100%", background: s.color, borderRadius: 3 }} />
                        </div>
                        <span style={{ color: "#656D76", fontSize: 11.5, fontFamily: "monospace" }}>{p.progressPct || 0}%</span>
                      </div>
                    </td>
                    <td style={{ padding: "12px 14px", textAlign: "right", color: "#1F2328", fontSize: 13, fontFamily: "monospace", fontWeight: 600 }}>{fmt(Number(p.contractValue))}</td>
                    <td style={{ padding: "12px 14px", color: "#656D76", fontSize: 12.5 }}>{p.members?.find((m: any) => m.role === "PROJECT_MANAGER" || m.role === "OWNER")?.user?.name?.split(" ")[0] || "—"}</td>
                    <td style={{ padding: "12px 14px" }}>
                      <Link href={`/projects/${p.id}`} style={{ background: "#F0F4F8", border: "1px solid #D0D7DE", color: "#656D76", padding: "5px 12px", borderRadius: 6, fontSize: 12, textDecoration: "none", fontWeight: 600 }}>Open →</Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Grid view */}
      {!loading && filtered.length > 0 && view === "grid" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
          {filtered.map(p => {
            const s = STATUS[p.status] || STATUS.ACTIVE;
            return (
              <Link key={p.id} href={`/projects/${p.id}`} style={{ background: "#fff", border: `1px solid #D0D7DE`, borderRadius: 10, overflow: "hidden", textDecoration: "none", display: "block", transition: "all 0.15s", borderTop: `3px solid ${s.color}` }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(0,0,0,0.1)"; (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "none"; (e.currentTarget as HTMLElement).style.transform = "none"; }}>
                <div style={{ padding: "14px 16px", borderBottom: "1px solid #F0F4F8", background: "#F6F8FA" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
                    <div style={{ color: "#9198A1", fontSize: 10.5, fontWeight: 700, textTransform: "uppercase" }}>{p.code} · {p.projectType?.replace(/_/g," ")}</div>
                    <span style={{ background: s.bg, border: `1px solid ${s.bd}`, color: s.color, fontSize: 10, fontWeight: 700, padding: "2px 7px", borderRadius: 20 }}>{s.label}</span>
                  </div>
                  <div style={{ color: "#1F2328", fontSize: 14, fontWeight: 700 }}>{p.name}</div>
                  <div style={{ color: "#9198A1", fontSize: 12, marginTop: 2 }}>📍 {p.location} · {p.clientName}</div>
                </div>
                <div style={{ padding: "12px 16px" }}>
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                      <span style={{ color: "#656D76", fontSize: 11.5 }}>Progress</span>
                      <span style={{ color: "#1F2328", fontSize: 12, fontWeight: 700, fontFamily: "monospace" }}>{p.progressPct || 0}%</span>
                    </div>
                    <div style={{ background: "#E4E9F0", borderRadius: 3, height: 6, overflow: "hidden" }}>
                      <div style={{ width: `${p.progressPct || 0}%`, height: "100%", background: s.color, borderRadius: 3 }} />
                    </div>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ color: "#1F2328", fontSize: 14, fontWeight: 700, fontFamily: "monospace" }}>{fmt(Number(p.contractValue))}</span>
                    <span style={{ color: "#9198A1", fontSize: 11.5 }}>{p.members?.length || 0} members</span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

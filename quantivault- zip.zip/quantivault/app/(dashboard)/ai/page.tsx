"use client";
import { useEffect, useState, useRef } from "react";

export default function AIPage() {
  const [insights, setInsights]     = useState<any[]>([]);
  const [messages, setMessages]     = useState<any[]>([{ role:"assistant", content:"Hi! I've analysed your portfolio. Ask me anything about your projects, costs, payments, or risks." }]);
  const [input, setInput]           = useState("");
  const [loading, setLoading]       = useState(false);
  const [streaming, setStreaming]   = useState("");
  const [tab, setTab]               = useState("insights");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { fetch("/api/ai/insights").then(r=>r.json()).then(d=>setInsights(d.data||[])); }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages, streaming]);

  const sendMessage = async (text?: string) => {
    const q = text || input.trim();
    if (!q || loading) return;
    setInput(""); setLoading(true); setStreaming("");
    const newMessages = [...messages, { role:"user", content:q }];
    setMessages(newMessages);
    try {
      const res = await fetch("/api/ai/chat", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ messages: newMessages }) });
      const reader = res.body?.getReader();
      if (!reader) throw new Error("No stream");
      let full = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = new TextDecoder().decode(value);
        for (const line of text.split("\n")) {
          if (line.startsWith("data: ") && line !== "data: [DONE]") {
            try { const d = JSON.parse(line.slice(6)); full += d.text; setStreaming(full); } catch {}
          }
        }
      }
      setMessages(m => [...m, { role:"assistant", content:full }]);
      setStreaming("");
    } catch { setMessages(m => [...m, { role:"assistant", content:"Sorry, I encountered an error. Please try again." }]); }
    setLoading(false);
  };

  const SEVER: Record<string,any> = { CRITICAL:{color:"#CF222E",bg:"#FFEBE9"}, WARNING:{color:"#9A6700",bg:"#FFF8C5"}, INFO:{color:"#0969DA",bg:"#DDF4FF"} };
  const TYPE: Record<string,string> = { OVERRUN_PREDICTION:"📉", ANOMALY_DETECTED:"🚨", CASHFLOW_ALERT:"💸", PERFORMANCE_SUMMARY:"📊", PROCUREMENT_RECOMMENDATION:"🛒", SCHEDULE_RISK:"⏱" };

  const PROMPTS = ["What is my portfolio CPI?","Which project has the highest overrun risk?","What payments are overdue?","Summarise all active projects","What's our total retention held?"];

  return (
    <div>
      <div style={{marginBottom:20}}>
        <h1 style={{color:"#1F2328",fontSize:21,fontWeight:700,margin:0}}>AI Insights</h1>
        <p style={{color:"#656D76",fontSize:13,marginTop:4}}>Powered by Claude · Real-time portfolio intelligence</p>
      </div>
      <div style={{display:"flex",background:"#fff",border:"1px solid #D0D7DE",borderRadius:8,padding:3,marginBottom:18,width:"fit-content",gap:2}}>
        {[["insights","Insights Feed"],["chat","AI Assistant"]].map(([id,label])=>(<button key={id} onClick={()=>setTab(id)} style={{padding:"7px 18px",borderRadius:6,border:"none",cursor:"pointer",fontSize:13,fontWeight:600,background:tab===id?"#1B3A2D":"transparent",color:tab===id?"#fff":"#656D76"}}>{label}</button>))}
      </div>
      {tab==="insights" && (
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {insights.length===0 && <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,padding:60,textAlign:"center",color:"#9198A1"}}>No active insights. Run a portfolio scan to generate AI analysis.</div>}
          {insights.map((ins:any)=>{
            const s = SEVER[ins.severity]||SEVER.INFO;
            return (
              <div key={ins.id} style={{background:s.bg,border:`1px solid ${s.color}44`,borderRadius:10,padding:"16px 18px",borderLeft:`3px solid ${s.color}`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{fontSize:18}}>{TYPE[ins.type]||"💡"}</span>
                    <span style={{background:s.color,color:"#fff",fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:20}}>{ins.severity}</span>
                  </div>
                  <span style={{color:"#9198A1",fontSize:11}}>{new Date(ins.createdAt).toLocaleDateString()}</span>
                </div>
                <div style={{color:"#1F2328",fontSize:14,fontWeight:700,marginBottom:6}}>{ins.title}</div>
                <div style={{color:"#656D76",fontSize:13,lineHeight:1.6}}>{ins.body}</div>
                {ins.project && <div style={{marginTop:8,color:"#9198A1",fontSize:12}}>Project: {ins.project.name}</div>}
              </div>
            );
          })}
        </div>
      )}
      {tab==="chat" && (
        <div style={{background:"#fff",border:"1px solid #D0D7DE",borderRadius:10,display:"flex",flexDirection:"column",height:"calc(100vh - 260px)"}}>
          <div style={{padding:"14px 16px",borderBottom:"1px solid #D0D7DE",display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:28,height:28,borderRadius:"50%",background:"linear-gradient(135deg,#2B6FE8,#1A3A8F)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>✨</div>
            <div><div style={{color:"#1F2328",fontSize:13,fontWeight:700}}>Quantivault AI Assistant</div><div style={{color:"#1A7F37",fontSize:10.5,display:"flex",alignItems:"center",gap:4}}><div style={{width:6,height:6,borderRadius:"50%",background:"#1A7F37"}}/>Live · Powered by Claude</div></div>
          </div>
          <div style={{flex:1,overflowY:"auto",padding:16,display:"flex",flexDirection:"column",gap:10}}>
            {messages.map((m:any,i:number)=>(
              <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start",gap:8}}>
                {m.role==="assistant"&&<div style={{width:26,height:26,borderRadius:"50%",background:"linear-gradient(135deg,#2B6FE8,#1A3A8F)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,flexShrink:0,marginTop:2}}>✨</div>}
                <div style={{maxWidth:"78%",padding:"10px 14px",borderRadius:10,fontSize:13,lineHeight:1.6,background:m.role==="user"?"#1B3A2D":"#F6F8FA",color:m.role==="user"?"#fff":"#1F2328",border:m.role==="user"?"none":"1px solid #D0D7DE",borderBottomRightRadius:m.role==="user"?3:10,borderBottomLeftRadius:m.role==="assistant"?3:10,whiteSpace:"pre-wrap"}}>{m.content}</div>
              </div>
            ))}
            {streaming && (
              <div style={{display:"flex",gap:8}}>
                <div style={{width:26,height:26,borderRadius:"50%",background:"linear-gradient(135deg,#2B6FE8,#1A3A8F)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,flexShrink:0,marginTop:2}}>✨</div>
                <div style={{maxWidth:"78%",padding:"10px 14px",borderRadius:10,fontSize:13,lineHeight:1.6,background:"#F6F8FA",border:"1px solid #D0D7DE",whiteSpace:"pre-wrap"}}>{streaming}<span style={{opacity:0.5}}>▊</span></div>
              </div>
            )}
            <div ref={endRef}/>
          </div>
          <div style={{padding:"10px 16px",borderTop:"1px solid #D0D7DE"}}>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
              {PROMPTS.map(p=>(<button key={p} onClick={()=>sendMessage(p)} disabled={loading} style={{background:"#F6F8FA",border:"1px solid #D0D7DE",color:"#656D76",padding:"4px 10px",borderRadius:20,fontSize:11.5,cursor:"pointer"}}>{p}</button>))}
            </div>
            <div style={{display:"flex",gap:8}}>
              <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&sendMessage()} disabled={loading} placeholder="Ask about your portfolio..." style={{flex:1,border:"1px solid #D0D7DE",borderRadius:8,padding:"9px 12px",fontSize:13,outline:"none",fontFamily:"inherit"}}/>
              <button onClick={()=>sendMessage()} disabled={loading||!input.trim()} style={{background:loading||!input.trim()?"#D0D7DE":"#1B3A2D",color:"#fff",border:"none",padding:"9px 16px",borderRadius:8,fontSize:15,cursor:loading||!input.trim()?"not-allowed":"pointer",fontWeight:700}}>↑</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

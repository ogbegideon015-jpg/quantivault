"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const router       = useSearchParams();
  const nav          = useRouter();
  const callbackUrl  = router.get("callbackUrl") || "/dashboard";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    const res = await signIn("credentials", { email, password, redirect: false });
    if (res?.error) { setError("Invalid email or password. Please try again."); setLoading(false); return; }
    nav.push(callbackUrl);
  };

  const inputStyle: React.CSSProperties = {
    width: "100%", background: "#1A2535", border: "1px solid #2E3D52",
    borderRadius: 8, padding: "12px 14px", color: "#D8E4F0",
    fontSize: 14, outline: "none", fontFamily: "inherit", boxSizing: "border-box",
  };

  return (
    <div style={{ display: "flex", width: "100%", minHeight: "100vh" }}>
      {/* Left — branding */}
      <div style={{ flex: 1, background: "linear-gradient(145deg, #111418 0%, #1A2535 60%, #0A1018 100%)", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "48px", backgroundImage: "linear-gradient(rgba(43,95,232,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(43,95,232,0.05) 1px, transparent 1px)", backgroundSize: "40px 40px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 40, height: 40, background: "linear-gradient(135deg, #2B6FE8, #1A3A8F)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: 900, color: "#fff" }}>Q</div>
          <div>
            <div style={{ color: "#D8E4F0", fontSize: 18, fontWeight: 700 }}>Quantivault</div>
            <div style={{ color: "#4A5E78", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.15em" }}>Construction Intelligence</div>
          </div>
        </div>
        <div>
          <h1 style={{ color: "#D8E4F0", fontSize: 40, fontWeight: 800, lineHeight: 1.2, marginBottom: 16 }}>Every naira.<br />Accounted for.</h1>
          <p style={{ color: "#7A8EA8", fontSize: 16, lineHeight: 1.7, maxWidth: 380 }}>Real-time budget tracking, EVM, procurement, and AI-powered insights — built for Nigerian construction firms.</p>
          <div style={{ marginTop: 32, display: "flex", flexDirection: "column", gap: 10 }}>
            {["💰 Full Earned Value Management — CPI, SPI, EAC in real time", "🏗️ Site diaries, labour tracking, and material delivery logs", "✨ AI budget overrun prediction and anomaly detection", "📊 Automated cost reports — PDF, Excel"].map(f => (
              <div key={f} style={{ display: "flex", gap: 10, padding: "10px 14px", background: "rgba(255,255,255,0.04)", borderRadius: 8, border: "1px solid rgba(255,255,255,0.06)" }}>
                <span style={{ color: "#7A8EA8", fontSize: 13 }}>{f}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ color: "#4A5E78", fontSize: 12 }}>Trusted by construction firms managing over ₦50B in project value</div>
      </div>

      {/* Right — form */}
      <div style={{ width: 460, background: "#fff", display: "flex", flexDirection: "column", justifyContent: "center", padding: "48px" }}>
        <h2 style={{ color: "#0D1520", fontSize: 26, fontWeight: 700, margin: "0 0 6px" }}>Welcome back</h2>
        <p style={{ color: "#4A5A72", fontSize: 14, margin: "0 0 32px" }}>Sign in to your workspace</p>

        {error && (
          <div style={{ background: "#FEF2F2", border: "1px solid #FCA5A5", borderRadius: 8, padding: "12px 14px", marginBottom: 20, color: "#B91C1C", fontSize: 13 }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <label style={{ color: "#4A5A72", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", display: "block", marginBottom: 6 }}>Email Address</label>
            <input value={email} onChange={e => setEmail(e.target.value)} type="email" required placeholder="you@company.com"
              style={{ width: "100%", border: "1.5px solid #CDD5E0", borderRadius: 8, padding: "12px 14px", fontSize: 14, outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
              onFocus={e => e.target.style.borderColor = "#2B6FE8"}
              onBlur={e  => e.target.style.borderColor = "#CDD5E0"} />
          </div>
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <label style={{ color: "#4A5A72", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em" }}>Password</label>
              <Link href="/forgot-password" style={{ color: "#2B6FE8", fontSize: 12.5, textDecoration: "none" }}>Forgot password?</Link>
            </div>
            <input value={password} onChange={e => setPassword(e.target.value)} type="password" required placeholder="••••••••"
              style={{ width: "100%", border: "1.5px solid #CDD5E0", borderRadius: 8, padding: "12px 14px", fontSize: 14, outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
              onFocus={e => e.target.style.borderColor = "#2B6FE8"}
              onBlur={e  => e.target.style.borderColor = "#CDD5E0"} />
          </div>
          <button type="submit" disabled={loading}
            style={{ background: loading ? "#9CA3AF" : "#1A2332", color: "#fff", border: "none", padding: "13px", borderRadius: 8, fontSize: 15, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", marginTop: 4, transition: "all 0.2s" }}>
            {loading ? "Signing in..." : "Sign In →"}
          </button>
        </form>

        <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "20px 0" }}>
          <div style={{ flex: 1, height: 1, background: "#E4E9F0" }} /><span style={{ color: "#9CA3AF", fontSize: 12 }}>or</span><div style={{ flex: 1, height: 1, background: "#E4E9F0" }} />
        </div>

        <button onClick={() => signIn("google", { callbackUrl })}
          style={{ background: "#F8FAFD", border: "1px solid #CDD5E0", color: "#1A2332", padding: "11px 14px", borderRadius: 8, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 10, fontWeight: 600, justifyContent: "center" }}>
          <span style={{ fontSize: 18 }}>🔵</span> Continue with Google
        </button>

        <div style={{ marginTop: 24, textAlign: "center", color: "#9CA3AF", fontSize: 12.5 }}>
          Don't have an account?{" "}
          <Link href="/register" style={{ color: "#2B6FE8", fontWeight: 700, textDecoration: "none" }}>Start free trial →</Link>
        </div>

        <div style={{ marginTop: 32, padding: "14px", background: "#F0F9FF", border: "1px solid #7DD3FC", borderRadius: 8 }}>
          <div style={{ color: "#0369A1", fontSize: 12, fontWeight: 700, marginBottom: 6 }}>Demo Credentials</div>
          <div style={{ color: "#0369A1", fontSize: 12 }}>📧 gideon@demo.com</div>
          <div style={{ color: "#0369A1", fontSize: 12 }}>🔑 Demo@1234</div>
        </div>
      </div>
    </div>
  );
}

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ minHeight: "100vh", background: "#111418", display: "flex" }}>
      {children}
    </div>
  );
}

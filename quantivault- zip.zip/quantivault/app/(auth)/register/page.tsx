"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: "", email: "", password: "", companyName: "", country: "NG", currency: "NGN" });
  const [otp, setOtp]   = useState("");
  const [userId, setUserId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");
  const nav = useRouter();

  const update = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError("");
    const res  = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) { setError(data.error || "Registration failed"); setLoading(false); return; }
    setUserId(data.userId);
    setStep(2);
    setLoading(false);
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError("");
    const res  = await fetch("/api/auth/verify-email", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, otp }) });
    const data = await res.json();
    if (!res.ok) { setError(data.error || "Verification failed"); setLoading(false); return; }
    nav.push("/login?registered=true");
  };

  const inp: React.CSSProperties = { width: "100%", border: "1.5px solid #CDD5E0", borderRadius: 8, padding: "11px 13px", fontSize: 14, outline: "none", fontFamily: "inherit", boxSizing: "border-box" };
  const lbl: React.CSSProperties = { color: "#4A5A72", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", display: "block", marginBottom: 5 };

  return (
    <div style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ background: "#fff", borderRadius: 14, padding: "40px 48px", width: "100%", maxWidth: 480, boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 28 }}>
          <div style={{ width: 32, height: 32, background: "linear-gradient(135deg,#2B6FE8,#1A3A8F)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 900, fontSize: 16 }}>Q</div>
          <span style={{ color: "#0D1520", fontSize: 16, fontWeight: 700 }}>Quantivault</span>
        </div>

        {/* Step indicators */}
        <div style={{ display: "flex", gap: 8, marginBottom: 28 }}>
          {["Account Details", "Verify Email"].map((s, i) => (
            <div key={s} style={{ flex: 1, padding: "6px 10px", borderRadius: 6, background: step === i+1 ? "#1A2332" : step > i+1 ? "#DAFBE1" : "#F0F4F8", textAlign: "center", fontSize: 12, fontWeight: 700, color: step === i+1 ? "#fff" : step > i+1 ? "#1A6B3C" : "#9CA3AF" }}>
              {step > i+1 ? "✓ " : ""}{s}
            </div>
          ))}
        </div>

        {error && <div style={{ background: "#FEF2F2", border: "1px solid #FCA5A5", borderRadius: 8, padding: "10px 14px", marginBottom: 16, color: "#B91C1C", fontSize: 13 }}>{error}</div>}

        {step === 1 && (
          <form onSubmit={handleRegister} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <h2 style={{ color: "#0D1520", fontSize: 22, fontWeight: 700, margin: "0 0 4px" }}>Create your account</h2>
            <p style={{ color: "#9CA3AF", fontSize: 13, margin: "0 0 8px" }}>14-day free trial · No credit card required</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div><label style={lbl}>Your Name</label><input value={form.name} onChange={e=>update("name",e.target.value)} required placeholder="Gideon Ogbe" style={inp}/></div>
              <div><label style={lbl}>Company Name</label><input value={form.companyName} onChange={e=>update("companyName",e.target.value)} required placeholder="Acme Construction" style={inp}/></div>
            </div>
            <div><label style={lbl}>Work Email</label><input value={form.email} onChange={e=>update("email",e.target.value)} type="email" required placeholder="you@company.com" style={inp}/></div>
            <div><label style={lbl}>Password</label><input value={form.password} onChange={e=>update("password",e.target.value)} type="password" required placeholder="Min 8 chars, 1 uppercase, 1 number" style={inp}/></div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={lbl}>Country</label>
                <select value={form.country} onChange={e=>update("country",e.target.value)} style={{ ...inp }}>
                  <option value="NG">Nigeria</option><option value="GH">Ghana</option><option value="KE">Kenya</option><option value="ZA">South Africa</option><option value="GB">United Kingdom</option><option value="US">United States</option>
                </select>
              </div>
              <div>
                <label style={lbl}>Currency</label>
                <select value={form.currency} onChange={e=>update("currency",e.target.value)} style={{ ...inp }}>
                  <option value="NGN">NGN — ₦</option><option value="GHS">GHS — ₵</option><option value="KES">KES — KSh</option><option value="ZAR">ZAR — R</option><option value="GBP">GBP — £</option><option value="USD">USD — $</option>
                </select>
              </div>
            </div>
            <button type="submit" disabled={loading} style={{ background: "#1A2332", color: "#fff", border: "none", padding: 13, borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", marginTop: 4 }}>
              {loading ? "Creating account..." : "Create Account →"}
            </button>
            <p style={{ textAlign: "center", color: "#9CA3AF", fontSize: 12.5 }}>
              Already have an account?{" "}<Link href="/login" style={{ color: "#2B6FE8", fontWeight: 700, textDecoration: "none" }}>Sign in</Link>
            </p>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={handleVerify} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <h2 style={{ color: "#0D1520", fontSize: 22, fontWeight: 700, margin: 0 }}>Check your email</h2>
            <p style={{ color: "#4A5A72", fontSize: 14 }}>We sent a 6-digit code to <strong>{form.email}</strong>. Enter it below to verify your account.</p>
            <div>
              <label style={lbl}>Verification Code</label>
              <input value={otp} onChange={e=>setOtp(e.target.value)} required maxLength={6} placeholder="000000"
                style={{ ...inp, fontSize: 28, letterSpacing: 12, textAlign: "center", fontFamily: "monospace", fontWeight: 700 }}/>
            </div>
            <button type="submit" disabled={loading} style={{ background: "#1A7F37", color: "#fff", border: "none", padding: 13, borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer" }}>
              {loading ? "Verifying..." : "Verify Email →"}
            </button>
            <button type="button" onClick={async () => { await fetch("/api/auth/verify-email", { method: "PUT", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ userId }) }); }}
              style={{ background: "transparent", border: "none", color: "#2B6FE8", fontSize: 13, cursor: "pointer" }}>
              Resend code
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

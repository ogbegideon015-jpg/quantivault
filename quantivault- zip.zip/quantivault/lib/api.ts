import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { ZodSchema } from "zod";

export type SessionUser = {
  id: string; name: string; email: string;
  role: string; companyId: string;
  company: { name: string; plan: string; logo?: string };
};

export class ApiError extends Error {
  constructor(public status: number, public message: string, public details?: unknown) { super(message); }
}

export async function requireAuth(req?: NextRequest): Promise<SessionUser> {
  const session = await auth();
  if (!session?.user) throw new ApiError(401, "Unauthorized");
  return session.user as SessionUser;
}

export async function requireRole(user: SessionUser, roles: string[]) {
  if (!roles.includes(user.role)) throw new ApiError(403, "Insufficient permissions");
}

export async function scopeToCompany(user: SessionUser) {
  return user.companyId;
}

export async function validate<T>(req: NextRequest, schema: ZodSchema<T>): Promise<T> {
  const body = await req.json();
  const result = schema.safeParse(body);
  if (!result.success) throw new ApiError(400, "Validation failed", result.error.flatten());
  return result.data;
}

export async function auditLog(params: {
  companyId: string; userId: string; action: string;
  entity: string; entityId: string; before?: unknown; after?: unknown; req?: NextRequest;
}) {
  await prisma.auditLog.create({
    data: {
      companyId: params.companyId, userId: params.userId,
      action: params.action, entity: params.entity, entityId: params.entityId,
      before: params.before as any, after: params.after as any,
      ipAddress: params.req?.headers.get("x-forwarded-for") || null,
    },
  });
}

export function ok(data: unknown, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}
export function created(data: unknown) {
  return NextResponse.json({ success: true, data }, { status: 201 });
}
export function handleError(error: unknown) {
  if (error instanceof ApiError) {
    return NextResponse.json({ success: false, error: error.message, details: error.details }, { status: error.status });
  }
  console.error("Unhandled error:", error);
  return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
}
export function apiHandler(handler: (req: NextRequest, ctx: any) => Promise<NextResponse>) {
  return async (req: NextRequest, ctx: any) => {
    try { return await handler(req, ctx); } catch (e) { return handleError(e); }
  };
}

export async function sendNotification(params: {
  companyId: string; userId?: string; role?: string;
  type: string; title: string; body: string; link?: string;
}) {
  if (params.userId) {
    await prisma.notification.create({ data: { userId: params.userId, type: params.type as any, title: params.title, body: params.body, link: params.link } });
    return;
  }
  if (params.role) {
    const users = await prisma.user.findMany({ where: { companyId: params.companyId, role: params.role as any, isActive: true }, select: { id: true } });
    await prisma.notification.createMany({ data: users.map(u => ({ userId: u.id, type: params.type as any, title: params.title, body: params.body, link: params.link })) });
  }
}

import { redis } from "@/lib/redis";
import crypto from "crypto";

export const generateOTP = () => String(Math.floor(100000 + Math.random() * 900000));
export const storeOTP    = (userId: string, otp: string) => redis.set(`otp:${userId}`, otp, { ex: 900 });
export const verifyOTP   = async (userId: string, otp: string) => {
  const stored = await redis.get<string>(`otp:${userId}`);
  if (!stored) return { valid: false, expired: true };
  const valid = stored === otp;
  if (valid) await redis.del(`otp:${userId}`);
  return { valid, expired: false };
};

export const generateResetToken = () => crypto.randomBytes(32).toString("hex");
export const storeResetToken    = (userId: string, token: string) => redis.set(`reset:${userId}`, token, { ex: 3600 });
export const verifyResetToken   = async (userId: string, token: string) => {
  const stored = await redis.get<string>(`reset:${userId}`);
  if (!stored) return { valid: false, expired: true };
  return { valid: stored === token, expired: false };
};
export const clearResetToken = (userId: string) => redis.del(`reset:${userId}`);

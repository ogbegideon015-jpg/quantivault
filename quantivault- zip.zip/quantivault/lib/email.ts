import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM   = process.env.RESEND_FROM_EMAIL || "Quantivault <noreply@resend.dev>";

export async function sendVerificationEmail(p: { to: string; name: string; otp: string }) {
  await resend.emails.send({
    from: FROM, to: p.to, subject: "Verify your Quantivault account",
    html: `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:40px 24px">
      <h1 style="color:#1B3A2D">Verify your email</h1>
      <p>Hi ${p.name}, your verification code is:</p>
      <div style="background:#F4F7FA;border:2px solid #D4D8E0;border-radius:12px;padding:24px;text-align:center;margin:24px 0">
        <span style="font-size:40px;font-weight:900;letter-spacing:12px;color:#1B3A2D;font-family:monospace">${p.otp}</span>
      </div>
      <p style="color:#9CA3AF;font-size:13px">Expires in 15 minutes. Do not share with anyone.</p>
    </div>`,
  });
}

export async function sendWelcomeEmail(p: { to: string; name: string; companyName: string }) {
  await resend.emails.send({
    from: FROM, to: p.to, subject: `Welcome to Quantivault — ${p.companyName}`,
    html: `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:40px 24px">
      <h1 style="color:#1B3A2D">You're all set, ${p.name}!</h1>
      <p>Your workspace for <strong>${p.companyName}</strong> is ready.</p>
      <a href="${process.env.NEXTAUTH_URL}/dashboard" style="display:inline-block;background:#1B3A2D;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin-top:16px">Go to Dashboard →</a>
      <p style="color:#9CA3AF;font-size:13px;margin-top:24px">You're on the 14-day free trial. No credit card required.</p>
    </div>`,
  });
}

export async function sendPasswordResetEmail(p: { to: string; name: string; resetUrl: string }) {
  await resend.emails.send({
    from: FROM, to: p.to, subject: "Reset your Quantivault password",
    html: `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:40px 24px">
      <h1 style="color:#1B3A2D">Reset your password</h1>
      <p>Hi ${p.name}, we received a request to reset your password.</p>
      <a href="${p.resetUrl}" style="display:inline-block;background:#1B3A2D;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin:20px 0">Reset Password →</a>
      <p style="color:#9CA3AF;font-size:13px">Expires in 1 hour. If you didn't request this, ignore this email.</p>
    </div>`,
  });
}

export async function sendInviteEmail(p: { to: string; invitedBy: string; companyName: string; role: string; acceptUrl: string }) {
  const roles: Record<string,string> = { ADMIN:"Admin", PROJECT_MANAGER:"Project Manager", QUANTITY_SURVEYOR:"Quantity Surveyor", SITE_MANAGER:"Site Manager", FINANCE:"Finance", VIEWER:"Viewer" };
  await resend.emails.send({
    from: FROM, to: p.to, subject: `You've been invited to join ${p.companyName} on Quantivault`,
    html: `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:40px 24px">
      <h1 style="color:#1B3A2D;font-size:22px">${p.invitedBy} invited you to Quantivault</h1>
      <p>You've been invited to join <strong>${p.companyName}</strong> as a <strong>${roles[p.role] || p.role}</strong>.</p>
      <a href="${p.acceptUrl}" style="display:inline-block;background:#1B3A2D;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:700;margin:20px 0">Accept Invitation →</a>
      <p style="color:#9CA3AF;font-size:13px">This invitation expires in 48 hours.</p>
    </div>`,
  });
}
